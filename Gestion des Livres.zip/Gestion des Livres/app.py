from flask import Flask , render_template , jsonify , request
from flask_pymongo import PyMongo 
import datetime

app = Flask (__name__)


app.config["MONGO_URI"] = "mongodb://localhost:27017/mydatabase"
mongo = PyMongo(app)

@app.route("/")

def index ():
    return render_template("index.html")
 

## 1. Lister tous les livres (GET)
@app.route("/books", methods=["GET"])


def lister_livres():
    try:
        books_collection = mongo.db.books
        lbooks = []
        for b in books_collection.find():
            lbooks.append({
                "isbn": b["isbn"],
                "titre": b["titre"],
                "auteur": b["auteur"],
                "date_creation": b.get("date_creation", "Non spécifié")
            })
        return jsonify(lbooks), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500


## 2. Ajouter un nouveau livre (POST)
@app.route("/books", methods=["POST"])
def ajouter_livre():
    try:
        data = request.get_json()
        if not all(key in data for key in ("isbn", "titre", "auteur")):
            return jsonify({"error": "Données manquantes. Les champs 'isbn', 'titre', et 'auteur' sont requis."}), 400

        books_collection = mongo.db.books
        livre = {
            "isbn": data["isbn"],
            "titre": data["titre"],
            "auteur": data["auteur"],
            "date_creation": datetime.datetime.utcnow()
        }
        books_collection.insert_one(livre)
        return jsonify({"message": "Livre ajouté avec succès"}), 201
    except Exception as e:
        return jsonify({"error": str(e)}), 500


## 3. Modifier un livre (PUT)
@app.route("/books/<isbn>", methods=["PUT"])
def modifier_livre(isbn):
    try:
        data = request.get_json()
        if not data:
            return jsonify({"error": "Aucune donnée fournie pour la mise à jour."}), 400

        books_collection = mongo.db.books
        mise_a_jour = {}

        if "titre" in data:
            mise_a_jour["titre"] = data["titre"]
        if "auteur" in data:
            mise_a_jour["auteur"] = data["auteur"]

        if not mise_a_jour:
            return jsonify({"error": "Aucun champ valide fourni pour la mise à jour."}), 400

        result = books_collection.update_one({"isbn": isbn}, {"$set": mise_a_jour})

        if result.matched_count == 0:
            return jsonify({"error": "Livre non trouvé."}), 404

        return jsonify({"message": "Livre mis à jour avec succès."}), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500


## 4. Supprimer un livre (DELETE)
@app.route("/books/<isbn>", methods=["DELETE"])
def supprimer_livre(isbn):
    try:
        books_collection = mongo.db.books
        result = books_collection.delete_one({"isbn": isbn})

        if result.deleted_count == 0:
            return jsonify({"error": "Livre non trouvé"}), 404

        return jsonify({"message": "Livre supprimé avec succès"}), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500    

if __name__ == "__main__":
    app.run(debug=True)
