from flask import Flask , render_template

app = Flask (__name__)
@app.route("/")

def showapp ():
   return render_template("index.html")

if __name__ == "__main__"
     app.run(debug = true , port = 80)

from flask import Flask , render_template , jsonify 

from flask import Flask , render_template , jsonify 
from flask_pymongo import Pymongo 
app = Flask (__name__) 
app.config["MONGO_URL"] = "mongodb://localhost:27017/books
mongo = PyMongo(app)
@app.route("/")

def index():
   return render_template ("index.html")
@app.route("(/books" , methods = ['GET'])

def lister_livres():
   cc ==mongo.db.books
lbooks  = list()
for b in cc.find():
    lbooks.append({"isbn":["isbn"],"titre" : b["titre"] , "auteur" : b["auteur"]})
return jsonify(lbooks)

if__name__== "__main__" :
app.run(port = 80)
