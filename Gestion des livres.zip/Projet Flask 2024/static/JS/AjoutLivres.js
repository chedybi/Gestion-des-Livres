document.addEventListener("DOMContentLoaded", () => {
    const addBookForm = document.getElementById("addBookForm");

    addBookForm.addEventListener("submit", (event) => {
        event.preventDefault();

        // Récupérer les données du formulaire
        const formData = new FormData(addBookForm);
        const bookData = Object.fromEntries(formData);

        console.log("Ajout d'un nouveau livre :", bookData);

        // Appeler une API ou une méthode backend pour ajouter le livre
        fetch('/api/books', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(bookData)
        })
        .then(response => response.json())
        .then(data => {
            console.log("Livre ajouté avec succès :", data);
            // Réinitialiser le formulaire
            addBookForm.reset();
        })
        .catch(error => console.error("Erreur lors de l'ajout du livre :", error));
    });
});
