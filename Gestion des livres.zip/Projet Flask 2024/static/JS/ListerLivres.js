const apiBaseUrl = "/books";

// Rafraîchir la liste des livres
async function fetchBooks() {
    try {
        const response = await fetch(apiBaseUrl);
        if (!response.ok) {
            throw new Error("Erreur lors de la récupération des livres");
        }
        const books = await response.json();
        const booksTable = document.querySelector("#booksTable tbody");
        booksTable.innerHTML = "";

        books.forEach(book => {
            const row = document.createElement("tr");
            row.innerHTML = `
                <td>${book.isbn}</td>
                <td>${book.titre}</td>
                <td>${book.auteur}</td>
                <td>${book.date_creation}</td>
                <td>
                    <button class="btn small warning" onclick="populateUpdateForm('${book.isbn}', '${book.titre}', '${book.auteur}', '${book.date_creation}')">Modifier</button>
                    <button class="btn small danger" onclick="deleteBook('${book.isbn}')">Supprimer</button>
                </td>
            `;
            booksTable.appendChild(row);
        });

        showNotification("Liste des livres actualisée avec succès", "success");
    } catch (error) {
        console.error(error);
        showNotification("Impossible de charger la liste des livres", "error");
    }
}



// Notification visuelle
function showNotification(message, type) {
    const notification = document.createElement("div");
    notification.className = `notification ${type}`;
    notification.innerText = message;
    document.body.appendChild(notification);

    setTimeout(() => {
        notification.remove();
    }, 3000);
}

// Charger les livres au démarrage
document.querySelector("#refreshBooks").addEventListener("click", fetchBooks);
fetchBooks();
