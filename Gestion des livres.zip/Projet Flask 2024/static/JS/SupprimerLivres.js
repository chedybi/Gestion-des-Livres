document.addEventListener("DOMContentLoaded", () => {
    const booksTable = document.getElementById("booksTable");

    booksTable.addEventListener("click", (event) => {
        if (event.target.classList.contains("delete-book")) {
            const isbn = event.target.dataset.isbn;

            console.log("Suppression du livre avec ISBN :", isbn);

            // Appeler une API ou une méthode backend pour supprimer le livre
            fetch(`/api/books/${isbn}`, {
                method: 'DELETE'
            })
            .then(response => response.json())
            .then(data => {
                console.log("Livre supprimé avec succès :", data);
                // Supprimer la ligne du tableau
                event.target.closest("tr").remove();
            })
            .catch(error => console.error("Erreur lors de la suppression du livre :", error));
        }
    });
});
