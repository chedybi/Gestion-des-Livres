document.addEventListener("DOMContentLoaded", () => {
    const updateBookForm = document.getElementById("updateBookForm");

    updateBookForm.addEventListener("submit", (event) => {
        event.preventDefault();

        // Récupérer les données du formulaire
        const formData = new FormData(updateBookForm);
        const bookData = Object.fromEntries(formData);

        console.log("Modification d'un livre :", bookData);

        // Appeler une API ou une méthode backend pour modifier le livre
        fetch(`/api/books/${bookData.isbn}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(bookData)
        })
        .then(response => response.json())
        .then(data => {
            console.log("Livre modifié avec succès :", data);
            // Réinitialiser le formulaire
            updateBookForm.reset();
        })
        .catch(error => console.error("Erreur lors de la modification du livre :", error));
    });
});
