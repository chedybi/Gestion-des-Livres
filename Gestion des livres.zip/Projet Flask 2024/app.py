from flask import Flask, render_template, jsonify, request, redirect, url_for, flash # type: ignore
from flask_pymongo import PyMongo # type: ignore
import datetime
from bson.objectid import ObjectId # type: ignore
import os

app = Flask(__name__)
app.config["SECRET_KEY"] = os.urandom(24).hex()  # 🔥 Clé sécurisée
app.config["MONGO_URI"] = "mongodb://localhost:27017/mydatabase"
mongo = PyMongo(app)

@app.route("/")
def home():
    return render_template("index.html")


@app.route('/inscription', methods=['GET', 'POST'])
def inscription():
    if request.method == 'POST':
        # Récupérer les données du formulaire
        id_membre = request.form.get('id')
        nom = request.form.get('nom')
        prenom = request.form.get('prenom')
        date_naissance = request.form.get('date_naissance')
        email = request.form.get('email')
        adresse = request.form.get('adresse', '')  # Optionnel
        niveau_etudes = request.form.get('niveau_etudes', '')  # Optionnel
        filiere = request.form.get('filiere')
        mot_de_passe = request.form.get('mot_de_passe')

        # Vérification des champs obligatoires
        if not all([id_membre, nom, prenom, date_naissance, email, filiere, mot_de_passe]):
            flash("Tous les champs marqués par * sont obligatoires.", "error")
            return redirect(url_for('inscription'))

        # Insérer les données dans MongoDB
        mongo.db.membres.insert_one({
            "id": id_membre,
            "nom": nom,
            "prenom": prenom,
            "date_naissance": date_naissance,
            "email": email,
            "adresse": adresse,
            "niveau_etudes": niveau_etudes,
            "filiere": filiere,
            "mot_de_passe": mot_de_passe,
            "date_inscription": datetime.datetime.utcnow()
        })

        flash("Inscription réussie !", "success")
        return redirect(url_for('home'))

    return render_template('inscription.html')

@app.route("/categories")
def categories():
    return render_template("categories.html")

@app.route("/promotions")
def promotions():
    promotions = [
        {"title": "50% de réduction", "description": "Sur les livres poétiques cette semaine !", "image": "img/promotions.jpg"},
        {"title": "30% de réduction", "description": "Sur les livres historiques.", "image": "img/histoire_promo.jpg"},
        {"title": "10€ offerts", "description": "Pour tout achat de livres scientifiques d'une valeur > 50€ !", "image": "img/science_promo.jpg"},
        {"title": "10€ offerts", "description": "Pour tout achat de livres médicaux > 30€ !", "image": "img/medical_promo.jpg"}
    ]
    return render_template("promotions.html", promotions=promotions)

@app.route('/promotions/<int:promo_id>')
def details_promo(promo_id):
    promotions = {
       1: {
            "title": "50% de réduction sur les livres poétiques",
            "description": "Offre valable cette semaine !",
            "validity": "Valable jusqu'au 10 février 2024",
            "conditions": "Applicable uniquement sur les livres de poésie en stock.",
            "image": "img/promo_poetique.jpg",
            "products": [
                {"name": "Les Fleurs du Mal", "image": "img/fleurs_du_mal.jpg", "price": "15"},
                {"name": "Anthologie de la poésie française", "image": "img/anthologie_poesie.jpg", "price": "20"}
            ]
        },
        2: {
            "title": "30% de réduction sur les livres historiques",
            "description": "Jusqu'au 28 juillet !",
            "validity": "Valable jusqu'au 28 juillet 2024",
            "conditions": "Offre applicable sur tous les livres historiques de plus de 200 pages.",
            "image": "img/promo_histoire.jpg",
            "products": [
                {"name": "Une brève histoire du temps", "image": "img/histoire_temps.jpg", "price": "25"}
            ]
        },
        3: {
            "title": "10€ offerts pour l'achat de livres scientifiques",
            "description": "Jusqu'au 31 juin 2024 !",
            "validity": "Valable jusqu'au 31 juin 2024",
            "conditions": "Valable pour toute commande supérieure à 50€.",
            "image": "img/promo_science.jpg",
            "products": [
                {"name": "L'univers en 100 questions", "image": "img/univers_100_questions.jpg", "price": "30"}
            ]
        },
        4: {
            "title": "10€ offerts pour les livres médicaux",
            "description": "Jusqu'au 30 août 2024 !",
            "validity": "Valable jusqu'au 30 août 2024",
            "conditions": "Réduction appliquée en caisse sur présentation de la carte de fidélité.",
            "image": "img/promo_medical.jpg",
            "products": [
                {"name": "Atlas d’anatomie humaine", "image": "img/anatomie.jpg", "price": "45"}
            ]
        }
    }
    promo = promotions.get(promo_id)
    if promo:
        return render_template('details_promo.html', promo=promo)
    else:
        return "Promotion non trouvée", 404

@app.route("/books/<categorie>", methods=["GET"])
def lister_livres(categorie):
    livres = {
        "poetique": [
            {"titre": "Les Fleurs du Mal", "auteur": "Charles Baudelaire", "maison": "Gallimard", "tome": 1, "prix": 15},
            {"titre": "Alcools", "auteur": "Guillaume Apollinaire", "maison": "Flammarion", "tome": 1, "prix": 12},
            {"titre": "Le Spleen de Paris", "auteur": "Baudelaire", "maison": "Hachette", "tome": 1, "prix": 10}
        ],
        "histoire": [
            {"titre": "Histoire de France", "auteur": "Jules Michelet", "maison": "Folio", "tome": 3, "prix": 20},
            {"titre": "Les Croisades vues par les Arabes", "auteur": "Amin Maalouf", "maison": "J'ai Lu", "tome": 1, "prix": 14},
            {"titre": "L'histoire du Moyen Âge", "auteur": "Georges Duby", "maison": "Larousse", "tome": 1, "prix": 18}
        ],
        "scientifique": [
            {"titre": "Une brève histoire du temps", "auteur": "Stephen Hawking", "maison": "Flammarion", "tome": 1, "prix": 25},
            {"titre": "L'univers élégant", "auteur": "Brian Greene", "maison": "Dunod", "tome": 1, "prix": 22},
            {"titre": "Le gène égoïste", "auteur": "Richard Dawkins", "maison": "Odile Jacob", "tome": 1, "prix": 18}
        ],
        "medical": [
            {"titre": "L’Art de la Médecine", "auteur": "Jean Bernard", "maison": "PUF", "tome": 1, "prix": 30},
            {"titre": "Atlas d’anatomie humaine", "auteur": "Frank Netter", "maison": "Elsevier", "tome": 1, "prix": 40},
            {"titre": "Les Grandes Découvertes Médicales", "auteur": "Jean-Noël Fabiani", "maison": "Odile Jacob", "tome": 1, "prix": 28}
        ]
    }
    if categorie in livres:
        return render_template("livres.html", categorie=categorie, livres=livres[categorie])
    else:
        return "Catégorie non trouvée", 404


@app.route("/books/add", methods=["POST"])
def ajouter_livre():
    data = request.json
    if not data or not all(k in data for k in ("titre", "auteur", "maison", "tome", "prix", "categorie")):
        return jsonify({"error": "Données invalides"}), 400
    
    new_book = {
        "titre": data["titre"],
        "auteur": data["auteur"],
        "maison": data["maison"],
        "tome": data["tome"],
        "prix": data["prix"],
        "categorie": data["categorie"],
        "date_ajout": datetime.datetime.utcnow()
    }
    result = mongo.db.books.insert_one(new_book)
    return jsonify({"message": "Livre ajouté", "id": str(result.inserted_id)}), 201

@app.route("/books/update/<book_id>", methods=["PUT"])
def modifier_livre(book_id):
    data = request.json
    if not data:
        return jsonify({"error": "Aucune donnée reçue"}), 400
    
    update_data = {key: data[key] for key in data if key in ("titre", "auteur", "maison", "tome", "prix", "categorie")}
    
    result = mongo.db.books.update_one({"_id": ObjectId(book_id)}, {"$set": update_data})
    if result.matched_count == 0:
        return jsonify({"error": "Livre non trouvé"}), 404
    
    return jsonify({"message": "Livre mis à jour"}), 200

@app.route("/books/delete/<book_id>", methods=["DELETE"])
def supprimer_livre(book_id):
    result = mongo.db.books.delete_one({"_id": ObjectId(book_id)})
    if result.deleted_count == 0:
        return jsonify({"error": "Livre non trouvé"}), 404
    
    return jsonify({"message": "Livre supprimé"}), 200


if __name__ == "__main__":
    app.run(debug=True)